Documentation for the Skytap Automation Pack for IBM Rational Team Concert 
can be found at this URL:

http://help.skytap.com/#skytap_automation_pack_for_ibm_rational_team_concert

